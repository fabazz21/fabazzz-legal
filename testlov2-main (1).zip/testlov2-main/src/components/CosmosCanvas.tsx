import { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';

interface Firefly {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  acc: THREE.Vector3;
  history: THREE.Vector3[];
  color: THREE.Color;
  life: number;
  maxLife: number;
  birth: number;
  size: number;
}

const CONFIG = {
  fireflyCount: 500,
  trailLength: 25,
  attractionStrength: 0.6,
  wanderStrength: 0.04,
  maxSpeed: 0.5,
  friction: 0.96,
  spawnRadius: 35,
};

export default function CosmosCanvas() {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraRequested, setCameraRequested] = useState(false);
  const [handsDetected, setHandsDetected] = useState(false);
  const [gestureState, setGestureState] = useState<'idle' | 'open' | 'closed' | 'heart'>('idle');
  const [cameraError, setCameraError] = useState(false);
  const initHandTrackingRef = useRef<(() => Promise<void>) | null>(null);
  
  const handPositionsRef = useRef<{ left: THREE.Vector3 | null; right: THREE.Vector3 | null }>({
    left: null,
    right: null,
  });
  const fingertipsRef = useRef<THREE.Vector3[]>([]);
  const gestureRef = useRef<'idle' | 'open' | 'closed' | 'heart'>('idle');
  const handsDetectedRef = useRef(false);
  const mouseRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 0, 0));
  const isMouseActiveRef = useRef(false);
  const fireflyOpacityRef = useRef(0);

  const createFireflyTexture = useCallback(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const ctx = canvas.getContext('2d')!;
    
    const gradient = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
    gradient.addColorStop(0, 'rgba(255, 255, 255, 1)');
    gradient.addColorStop(0.15, 'rgba(255, 245, 220, 0.9)');
    gradient.addColorStop(0.4, 'rgba(255, 200, 100, 0.5)');
    gradient.addColorStop(0.7, 'rgba(255, 150, 50, 0.2)');
    gradient.addColorStop(1, 'rgba(255, 100, 30, 0)');
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 64, 64);
    
    const texture = new THREE.Texture(canvas);
    texture.needsUpdate = true;
    return texture;
  }, []);

  useEffect(() => {
    if (!containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x020008, 0.008);

    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.z = 25;

    const renderer = new THREE.WebGLRenderer({ 
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x020008, 1);
    containerRef.current.appendChild(renderer.domElement);

    // Poetic color palette
    const poeticColors = [
      new THREE.Color(0xffd700), // Gold
      new THREE.Color(0xffb347), // Warm amber
      new THREE.Color(0xff9f43), // Deep amber
      new THREE.Color(0x00d9ff), // Aurora cyan
      new THREE.Color(0x70dbff), // Light cyan
      new THREE.Color(0xff6b9d), // Rose
      new THREE.Color(0xffb6c1), // Light rose
      new THREE.Color(0xb388ff), // Lavender
      new THREE.Color(0xd4a5ff), // Light lavender
      new THREE.Color(0x7bed9f), // Mint
      new THREE.Color(0x98fb98), // Pale mint
    ];

    // Create fireflies
    const fireflies: Firefly[] = [];
    
    // Trail geometry
    const trailGeometry = new THREE.BufferGeometry();
    const trailPositions = new Float32Array(CONFIG.fireflyCount * CONFIG.trailLength * 3 * 2);
    const trailColors = new Float32Array(CONFIG.fireflyCount * CONFIG.trailLength * 3 * 2);
    
    trailGeometry.setAttribute('position', new THREE.BufferAttribute(trailPositions, 3));
    trailGeometry.setAttribute('color', new THREE.BufferAttribute(trailColors, 3));

    const trailMaterial = new THREE.LineBasicMaterial({
      vertexColors: true,
      blending: THREE.AdditiveBlending,
      transparent: true,
      opacity: 0.9,
      depthWrite: false,
    });
    const trailMesh = new THREE.LineSegments(trailGeometry, trailMaterial);
    scene.add(trailMesh);

    // Firefly heads
    const headsGeometry = new THREE.BufferGeometry();
    const headsPositions = new Float32Array(CONFIG.fireflyCount * 3);
    const headsSizes = new Float32Array(CONFIG.fireflyCount);
    const headsColors = new Float32Array(CONFIG.fireflyCount * 3);
    
    headsGeometry.setAttribute('position', new THREE.BufferAttribute(headsPositions, 3));
    headsGeometry.setAttribute('size', new THREE.BufferAttribute(headsSizes, 1));
    headsGeometry.setAttribute('color', new THREE.BufferAttribute(headsColors, 3));

    const headsMaterial = new THREE.PointsMaterial({
      size: 0.6,
      map: createFireflyTexture(),
      blending: THREE.AdditiveBlending,
      transparent: true,
      depthWrite: false,
      vertexColors: true,
      sizeAttenuation: true,
    });
    const headsMesh = new THREE.Points(headsGeometry, headsMaterial);
    scene.add(headsMesh);

    // Initialize fireflies
    for (let i = 0; i < CONFIG.fireflyCount; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      const r = Math.random() * CONFIG.spawnRadius;
      
      const pos = new THREE.Vector3(
        r * Math.sin(phi) * Math.cos(theta),
        r * Math.sin(phi) * Math.sin(theta) * 0.6,
        r * Math.cos(phi) * 0.5
      );

      const history: THREE.Vector3[] = [];
      for (let j = 0; j < CONFIG.trailLength; j++) {
        history.push(pos.clone());
      }

      const colorIndex = Math.floor(Math.random() * poeticColors.length);
      const baseColor = poeticColors[colorIndex].clone();
      baseColor.offsetHSL(
        (Math.random() - 0.5) * 0.08,
        (Math.random() - 0.5) * 0.15,
        (Math.random() - 0.5) * 0.15
      );

      fireflies.push({
        pos,
        vel: new THREE.Vector3(
          (Math.random() - 0.5) * 0.15,
          (Math.random() - 0.5) * 0.15,
          (Math.random() - 0.5) * 0.08
        ),
        acc: new THREE.Vector3(),
        history,
        color: baseColor,
        life: Math.random(),
        maxLife: 0.5 + Math.random() * 0.5,
        birth: Math.random() * Math.PI * 2,
        size: 0.3 + Math.random() * 0.4,
      });
    }

    // Background stars - multiple layers
    const createStarField = (count: number, spread: number, size: number, opacity: number) => {
      const geo = new THREE.BufferGeometry();
      const pos = new Float32Array(count * 3);
      for (let i = 0; i < count; i++) {
        pos[i * 3] = (Math.random() - 0.5) * spread;
        pos[i * 3 + 1] = (Math.random() - 0.5) * spread;
        pos[i * 3 + 2] = -30 - Math.random() * spread;
      }
      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      
      const mat = new THREE.PointsMaterial({
        color: 0xffffff,
        size,
        blending: THREE.AdditiveBlending,
        transparent: true,
        opacity,
        sizeAttenuation: true,
      });
      return new THREE.Points(geo, mat);
    };

    const starsNear = createStarField(800, 150, 0.15, 0.7);
    const starsFar = createStarField(1500, 300, 0.08, 0.4);
    const starsDistant = createStarField(2000, 400, 0.05, 0.25);
    scene.add(starsNear, starsFar, starsDistant);

    // Aurora shader
    const auroraGeometry = new THREE.PlaneGeometry(120, 60, 80, 40);
    const auroraMaterial = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
        uColor1: { value: new THREE.Color(0x00d9ff) },
        uColor2: { value: new THREE.Color(0x7bed9f) },
        uColor3: { value: new THREE.Color(0xb388ff) },
        uColor4: { value: new THREE.Color(0xff6b9d) },
      },
      vertexShader: `
        varying vec2 vUv;
        varying float vElevation;
        uniform float uTime;
        
        float noise(vec2 p) {
          return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
        }
        
        void main() {
          vUv = uv;
          vec3 pos = position;
          
          float wave1 = sin(pos.x * 0.08 + uTime * 0.3) * cos(pos.y * 0.05 + uTime * 0.2);
          float wave2 = sin(pos.x * 0.12 + uTime * 0.5 + 2.0) * cos(pos.y * 0.08 + uTime * 0.35);
          float elevation = (wave1 + wave2) * 3.0;
          
          pos.z += elevation;
          vElevation = elevation;
          
          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,
      fragmentShader: `
        varying vec2 vUv;
        varying float vElevation;
        uniform vec3 uColor1;
        uniform vec3 uColor2;
        uniform vec3 uColor3;
        uniform vec3 uColor4;
        uniform float uTime;
        
        void main() {
          float t = vUv.x + sin(uTime * 0.1) * 0.2;
          
          vec3 color;
          if (t < 0.33) {
            color = mix(uColor1, uColor2, t * 3.0);
          } else if (t < 0.66) {
            color = mix(uColor2, uColor3, (t - 0.33) * 3.0);
          } else {
            color = mix(uColor3, uColor4, (t - 0.66) * 3.0);
          }
          
          float alpha = (1.0 - vUv.y) * 0.2;
          alpha *= sin(vUv.x * 3.14159) * 0.7 + 0.3;
          alpha *= smoothstep(-3.0, 3.0, vElevation);
          alpha *= 0.4;
          
          gl_FragColor = vec4(color, alpha);
        }
      `,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const aurora = new THREE.Mesh(auroraGeometry, auroraMaterial);
    aurora.position.set(0, 20, -40);
    aurora.rotation.x = -Math.PI / 5;
    scene.add(aurora);

    // Second aurora layer
    const aurora2 = aurora.clone();
    aurora2.material = auroraMaterial.clone();
    aurora2.position.set(10, 18, -50);
    aurora2.rotation.z = 0.2;
    scene.add(aurora2);

    // Nebula clouds
    const nebulaGeometry = new THREE.SphereGeometry(60, 32, 32);
    const nebulaMaterial = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
      },
      vertexShader: `
        varying vec3 vPosition;
        varying vec3 vNormal;
        void main() {
          vPosition = position;
          vNormal = normal;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec3 vPosition;
        varying vec3 vNormal;
        uniform float uTime;
        
        void main() {
          float noise = fract(sin(dot(vPosition.xy * 0.01 + uTime * 0.05, vec2(12.9898, 78.233))) * 43758.5453);
          
          vec3 color1 = vec3(0.4, 0.1, 0.5);
          vec3 color2 = vec3(0.1, 0.2, 0.4);
          vec3 color = mix(color1, color2, noise);
          
          float rim = 1.0 - abs(dot(vNormal, vec3(0.0, 0.0, 1.0)));
          float alpha = rim * 0.1 * noise;
          
          gl_FragColor = vec4(color, alpha);
        }
      `,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.BackSide,
    });
    const nebula = new THREE.Mesh(nebulaGeometry, nebulaMaterial);
    nebula.position.z = -30;
    scene.add(nebula);

    // Mouse interaction
    const handleMouseMove = (e: MouseEvent) => {
      const x = ((e.clientX / window.innerWidth) - 0.5) * 40;
      const y = (-(e.clientY / window.innerHeight) + 0.5) * 30;
      mouseRef.current.set(x, y, 0);
      isMouseActiveRef.current = true;
    };

    const handleMouseLeave = () => {
      isMouseActiveRef.current = false;
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseleave', handleMouseLeave);

    // Hand tracking setup
    let handsInstance: any = null;
    let cameraInstance: any = null;

    const initHandTracking = async () => {
      try {
        const { Hands } = await import('@mediapipe/hands');
        const { Camera } = await import('@mediapipe/camera_utils');

        if (!videoRef.current) return;

        // Use the exact version that works (0.4.1646424915)
        handsInstance = new Hands({
          locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands@0.4.1646424915/${file}`,
        });

        handsInstance.setOptions({
          maxNumHands: 2,
          modelComplexity: 0, // Use lower complexity for stability
          minDetectionConfidence: 0.5,
          minTrackingConfidence: 0.5,
        });

        handsInstance.onResults((results: any) => {
          const landmarks = results.multiHandLandmarks;
          const handedness = results.multiHandedness;
          
          if (landmarks && landmarks.length > 0) {
            setHandsDetected(true);
            handsDetectedRef.current = true;
            handPositionsRef.current = { left: null, right: null };
            fingertipsRef.current = [];

            landmarks.forEach((hand: any, index: number) => {
              const wrist = hand[0];
              const handPos = new THREE.Vector3(
                (0.5 - wrist.x) * 35,
                (0.5 - wrist.y) * 26,
                0
              );

              const isRightHand = handedness?.[index]?.label === 'Right';
              if (isRightHand) {
                handPositionsRef.current.left = handPos;
              } else {
                handPositionsRef.current.right = handPos;
              }

              [4, 8, 12, 16, 20].forEach((tipIndex) => {
                const tip = hand[tipIndex];
                fingertipsRef.current.push(
                  new THREE.Vector3(
                    (0.5 - tip.x) * 35,
                    (0.5 - tip.y) * 26,
                    -tip.z * 8
                  )
                );
              });

              const thumbTip = hand[4];
              const indexTip = hand[8];
              const palmY = (hand[0].y + hand[9].y) / 2;
              
              const fingersUp = indexTip.y < palmY;
              const fingersClosed = indexTip.y > thumbTip.y;

              if (fingersUp) {
                gestureRef.current = 'open';
              } else if (fingersClosed) {
                gestureRef.current = 'closed';
              }
            });

            if (landmarks.length === 2) {
              const h1Index = landmarks[0][8];
              const h2Index = landmarks[1][8];
              const h1Thumb = landmarks[0][4];
              const h2Thumb = landmarks[1][4];

              const distIndex = Math.hypot(h1Index.x - h2Index.x, h1Index.y - h2Index.y);
              const distThumb = Math.hypot(h1Thumb.x - h2Thumb.x, h1Thumb.y - h2Thumb.y);

              if (distIndex < 0.15 && distThumb < 0.15) {
                gestureRef.current = 'heart';
              }
            }

            setGestureState(gestureRef.current);
          } else {
            setHandsDetected(false);
            handsDetectedRef.current = false;
            gestureRef.current = 'idle';
            setGestureState('idle');
            handPositionsRef.current = { left: null, right: null };
            fingertipsRef.current = [];
          }
        });

        // Simpler camera setup like in working code
        cameraInstance = new Camera(videoRef.current, {
          onFrame: async () => {
            // Only check videoWidth like in working example
            if (videoRef.current && videoRef.current.videoWidth > 0 && handsInstance) {
              await handsInstance.send({ image: videoRef.current });
            }
          },
          width: 640,
          height: 480,
        });

        await cameraInstance.start();
        setCameraActive(true);
        setIsLoading(false);
      } catch (error) {
        console.log('Camera not available, using mouse mode:', error);
        setCameraError(true);
        setIsLoading(false);
      }
    };

    // Store the init function so it can be called from button click
    initHandTrackingRef.current = initHandTracking;

    // Start loading but show content quickly
    setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    // Animation
    const clock = new THREE.Clock();

    const animate = () => {
      requestAnimationFrame(animate);
      const delta = Math.min(clock.getDelta(), 0.05);
      const time = clock.getElapsedTime();

      // Update shaders
      auroraMaterial.uniforms.uTime.value = time;
      if (aurora2.material instanceof THREE.ShaderMaterial) {
        aurora2.material.uniforms.uTime.value = time + 2;
      }
      nebulaMaterial.uniforms.uTime.value = time;

      // Rotate stars
      starsNear.rotation.y = time * 0.008;
      starsNear.rotation.x = Math.sin(time * 0.003) * 0.05;
      starsFar.rotation.y = time * 0.005;
      starsDistant.rotation.y = time * 0.003;

      // Fade fireflies based on hand detection
      const targetOpacity = handsDetectedRef.current ? 1 : 0;
      fireflyOpacityRef.current += (targetOpacity - fireflyOpacityRef.current) * delta * 3;
      
      trailMaterial.opacity = fireflyOpacityRef.current * 0.9;
      headsMaterial.opacity = fireflyOpacityRef.current;
      
      trailMesh.visible = fireflyOpacityRef.current > 0.01;
      headsMesh.visible = fireflyOpacityRef.current > 0.01;

      // Update fireflies
      const trailPosArray = trailMesh.geometry.attributes.position.array as Float32Array;
      const trailColArray = trailMesh.geometry.attributes.color.array as Float32Array;
      const headsPosArray = headsMesh.geometry.attributes.position.array as Float32Array;
      const headsSizeArray = headsMesh.geometry.attributes.size.array as Float32Array;
      const headsColArray = headsMesh.geometry.attributes.color.array as Float32Array;

      let trailIndex = 0;

      fireflies.forEach((firefly, i) => {
        firefly.acc.set(0, 0, 0);

        firefly.life += delta * 0.4;
        const lifePhase = Math.sin(firefly.life * Math.PI * 2 + firefly.birth) * 0.5 + 0.5;

        const { left, right } = handPositionsRef.current;
        const fingertips = fingertipsRef.current;
        const hasHandInput = left || right;
        const hasMouseInput = isMouseActiveRef.current;

        if (hasHandInput) {
          const targets = [left, right].filter(Boolean) as THREE.Vector3[];
          
          targets.forEach((target) => {
            const dir = new THREE.Vector3().subVectors(target, firefly.pos);
            const dist = dir.length();
            
            if (dist < 18) {
              dir.normalize();
              
              if (gestureRef.current === 'heart') {
                const spiral = new THREE.Vector3(-dir.y, dir.x, 0);
                firefly.acc.add(dir.multiplyScalar(CONFIG.attractionStrength * 1.8));
                firefly.acc.add(spiral.multiplyScalar(1.5));
              } else if (gestureRef.current === 'open') {
                // Main ouverte = tourbillon (swirl)
                const spiral = new THREE.Vector3(-dir.y, dir.x, 0);
                firefly.acc.add(dir.multiplyScalar(CONFIG.attractionStrength * 1.2));
                firefly.acc.add(spiral.multiplyScalar(1.2));
              } else if (gestureRef.current === 'closed') {
                // Poing fermé = dispersion (scatter)
                firefly.acc.sub(dir.multiplyScalar(CONFIG.attractionStrength * 1.5));
              } else {
                firefly.acc.add(dir.multiplyScalar(CONFIG.attractionStrength * 0.4));
              }

              if (dist < 2.5) {
                firefly.acc.sub(dir.multiplyScalar(0.6));
              }
            }
          });

          fingertips.forEach((tip) => {
            const dir = new THREE.Vector3().subVectors(tip, firefly.pos);
            const dist = dir.length();
            if (dist < 6) {
              dir.normalize();
              firefly.acc.add(dir.multiplyScalar(0.25 * (1 - dist / 6)));
            }
          });
        } else if (hasMouseInput) {
          // Mouse interaction
          const dir = new THREE.Vector3().subVectors(mouseRef.current, firefly.pos);
          const dist = dir.length();
          
          if (dist < 15) {
            dir.normalize();
            firefly.acc.add(dir.multiplyScalar(CONFIG.attractionStrength * 0.4 * (1 - dist / 15)));
            
            // Add spiral motion around mouse
            const spiral = new THREE.Vector3(-dir.y, dir.x, 0);
            firefly.acc.add(spiral.multiplyScalar(0.3));
          }
        }

        // Always add wandering behavior
        const wander = new THREE.Vector3(
          Math.sin(time * 1.3 + i * 0.15) * CONFIG.wanderStrength,
          Math.cos(time * 1.1 + i * 0.25) * CONFIG.wanderStrength,
          Math.sin(time * 0.8 + i * 0.1) * CONFIG.wanderStrength * 0.4
        );
        firefly.acc.add(wander);

        // Gentle return to center
        const centerForce = firefly.pos.clone().multiplyScalar(-0.0015);
        firefly.acc.add(centerForce);

        // Apply physics
        firefly.vel.add(firefly.acc.multiplyScalar(delta * 18));
        firefly.vel.multiplyScalar(CONFIG.friction);
        
        if (firefly.vel.length() > CONFIG.maxSpeed) {
          firefly.vel.normalize().multiplyScalar(CONFIG.maxSpeed);
        }

        firefly.pos.add(firefly.vel);

        // Update history
        firefly.history.shift();
        firefly.history.push(firefly.pos.clone());

        // Update head
        headsPosArray[i * 3] = firefly.pos.x;
        headsPosArray[i * 3 + 1] = firefly.pos.y;
        headsPosArray[i * 3 + 2] = firefly.pos.z;

        headsSizeArray[i] = firefly.size * (0.5 + lifePhase * 0.6);

        const displayColor = firefly.color.clone();
        displayColor.multiplyScalar(0.6 + lifePhase * 0.5);
        headsColArray[i * 3] = displayColor.r;
        headsColArray[i * 3 + 1] = displayColor.g;
        headsColArray[i * 3 + 2] = displayColor.b;

        // Update trails
        for (let j = 0; j < CONFIG.trailLength - 1; j++) {
          const p1 = firefly.history[j];
          const p2 = firefly.history[j + 1];

          trailPosArray[trailIndex] = p1.x;
          trailPosArray[trailIndex + 1] = p1.y;
          trailPosArray[trailIndex + 2] = p1.z;

          trailPosArray[trailIndex + 3] = p2.x;
          trailPosArray[trailIndex + 4] = p2.y;
          trailPosArray[trailIndex + 5] = p2.z;

          const alpha = Math.pow(j / CONFIG.trailLength, 1.3) * lifePhase;
          
          trailColArray[trailIndex] = firefly.color.r * alpha;
          trailColArray[trailIndex + 1] = firefly.color.g * alpha;
          trailColArray[trailIndex + 2] = firefly.color.b * alpha;

          trailColArray[trailIndex + 3] = firefly.color.r * alpha;
          trailColArray[trailIndex + 4] = firefly.color.g * alpha;
          trailColArray[trailIndex + 5] = firefly.color.b * alpha;

          trailIndex += 6;
        }
      });

      // Mark for update
      trailMesh.geometry.attributes.position.needsUpdate = true;
      trailMesh.geometry.attributes.color.needsUpdate = true;
      headsMesh.geometry.attributes.position.needsUpdate = true;
      headsMesh.geometry.attributes.size.needsUpdate = true;
      headsMesh.geometry.attributes.color.needsUpdate = true;

      renderer.render(scene, camera);
    };

    animate();

    // Resize handler
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
      if (cameraInstance) cameraInstance.stop();
      renderer.dispose();
      if (containerRef.current && renderer.domElement.parentNode === containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, [createFireflyTexture]);

  return (
    <>
      <div ref={containerRef} className="fixed inset-0 z-0" />
      
      {/* Single video element - always present */}
      <video
        ref={videoRef}
        playsInline
        className="fixed bottom-2 left-2 w-28 h-20 z-20"
        style={{ 
          transform: 'scaleX(-1)', 
          opacity: cameraActive ? 0.4 : 0,
          pointerEvents: 'none'
        }}
      />

      {/* Loading screen */}
      {isLoading && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background transition-opacity duration-1000">
          <div className="text-center">
            <div className="text-poetic-title text-2xl md:text-3xl text-primary animate-pulse-glow mb-6">
              Éveil du Cosmos
            </div>
            <div className="text-poetic-verse text-muted-foreground text-sm md:text-base">
              Les étoiles s'éveillent...
            </div>
          </div>
        </div>
      )}

      {/* Instructions overlay */}
      {!isLoading && (
        <div 
          className={`fixed top-16 left-0 right-0 z-10 text-center transition-all duration-1000 ${
            handsDetected ? 'opacity-0 -translate-y-4' : 'opacity-100 translate-y-0'
          }`}
        >
          <h2 className="text-poetic-verse text-lg md:text-xl text-foreground/70 text-glow-star px-4">
            {cameraActive 
              ? "Ouvrez vos mains devant la caméra"
              : "Déplacez votre souris pour guider les lucioles"
            }
          </h2>
          <p className="text-poetic-verse text-sm text-muted-foreground mt-2 px-4">
            {cameraActive 
              ? "et laissez les lucioles danser vers vous"
              : "ou cliquez ci-dessous pour une expérience gestuelle"
            }
          </p>
          
          {/* Camera activation button */}
          {!cameraActive && !cameraRequested && (
            <button
              onClick={() => {
                setCameraRequested(true);
                if (initHandTrackingRef.current) {
                  initHandTrackingRef.current();
                }
              }}
              className="mt-6 px-6 py-3 bg-primary/20 hover:bg-primary/30 border border-primary/40 rounded-full text-poetic-verse text-foreground/80 hover:text-foreground transition-all duration-300 backdrop-blur-sm hover:scale-105 active:scale-95"
            >
              ✋ Activer la caméra
            </button>
          )}
          
          {cameraRequested && !cameraActive && !cameraError && (
            <p className="mt-6 text-poetic-verse text-sm text-primary animate-pulse">
              Chargement de la détection des mains...
            </p>
          )}
          
          {cameraError && (
            <p className="mt-6 text-poetic-verse text-sm text-destructive/70">
              Caméra indisponible — utilisez la souris
            </p>
          )}
        </div>
      )}

      {/* Gesture feedback */}
      {handsDetected && (
        <div 
          className="fixed bottom-28 left-0 right-0 z-10 text-center transition-all duration-500"
        >
          <p className="text-poetic-verse text-base text-foreground/50 px-4">
            {gestureState === 'heart' && '💫 Cœur formé — les étoiles spiralent vers l\'infini'}
            {gestureState === 'open' && '✨ Mains ouvertes — les lucioles tourbillonnent'}
            {gestureState === 'closed' && '🌙 Poings fermés — elles se dispersent dans la nuit'}
            {gestureState === 'idle' && '🌟 Bougez doucement — le cosmos vous suit'}
          </p>
        </div>
      )}
    </>
  );
}
