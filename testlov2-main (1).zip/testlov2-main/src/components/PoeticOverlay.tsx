import { useEffect, useState } from 'react';

const verses = [
  "Dans le silence de l'univers, vos mains deviennent étoiles",
  "Chaque geste est un poème écrit dans la lumière",
  "Les lucioles du cosmos dansent à votre souffle",
  "Entre vos doigts coule la voie lactée",
  "Le temps suspend son vol quand vous touchez l'infini",
  "Les aurores naissent là où vos pensées s'éveillent",
  "Vous êtes le rêve que l'univers fait de lui-même",
];

export default function PoeticOverlay() {
  const [currentVerse, setCurrentVerse] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    // Delay initial appearance
    const showTimer = setTimeout(() => {
      setShowContent(true);
    }, 2000);

    return () => clearTimeout(showTimer);
  }, []);

  useEffect(() => {
    if (!showContent) return;

    const interval = setInterval(() => {
      setIsVisible(false);
      
      setTimeout(() => {
        setCurrentVerse((prev) => (prev + 1) % verses.length);
        setIsVisible(true);
      }, 1200);
    }, 10000);

    return () => clearInterval(interval);
  }, [showContent]);

  return (
    <div className={`fixed inset-0 pointer-events-none z-10 flex flex-col justify-between p-6 md:p-10 transition-opacity duration-2000 ${showContent ? 'opacity-100' : 'opacity-0'}`}>
      {/* Title */}
      <div className="text-center" style={{ animationDelay: '0.5s' }}>
        <h1 className="text-poetic-title text-2xl sm:text-3xl md:text-4xl lg:text-5xl text-foreground tracking-[0.2em] md:tracking-[0.3em] animate-fade-in-up" style={{ textShadow: '0 0 40px hsl(42 100% 70% / 0.5)' }}>
          Cosmos Intérieur
        </h1>
        <div className="h-px w-24 md:w-40 mx-auto mt-3 md:mt-5 bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
      </div>

      {/* Rotating verse */}
      <div 
        className={`text-center transition-all duration-1000 ease-out ${
          isVisible ? 'opacity-100 translate-y-0 blur-0' : 'opacity-0 translate-y-3 blur-sm'
        }`}
      >
        <p className="text-poetic-verse text-base sm:text-lg md:text-xl lg:text-2xl text-foreground/40 max-w-3xl mx-auto px-4 leading-relaxed">
          "{verses[currentVerse]}"
        </p>
      </div>

      {/* Footer */}
      <div className="text-center">
        <p className="text-[10px] md:text-xs text-muted-foreground/30 tracking-[0.2em] uppercase">
          Créé avec MediaPipe & Three.js
        </p>
      </div>
    </div>
  );
}
