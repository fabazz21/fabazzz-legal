import { Helmet } from 'react-helmet-async';
import CosmosCanvas from '@/components/CosmosCanvas';
import PoeticOverlay from '@/components/PoeticOverlay';

export default function Index() {
  return (
    <>
      <Helmet>
        <title>Cosmos Intérieur — Interactive Poetic Experience</title>
        <meta 
          name="description" 
          content="Une expérience poétique interactive où vos mains deviennent des portails vers l'univers. Dansez avec les lucioles cosmiques." 
        />
      </Helmet>
      
      <main className="relative w-screen h-screen overflow-hidden bg-background">
        <CosmosCanvas />
        <PoeticOverlay />
      </main>
    </>
  );
}
